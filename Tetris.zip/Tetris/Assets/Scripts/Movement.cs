﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public GameObject shapeL;
    // Start is called before the first frame update
    void Start()
    {
        //shapeL = GameObject.FindGameObjectWithTag("shapes");
        GameObject[] objects = GameObject.FindGameObjectsWithTag("myTag");
    }

    // Update is called once per frame
    void Update()
    {
        if (!(transform.position.y <= -40))
        {
            if (Input.GetKeyDown(KeyCode.DownArrow))
            {
                shapeL.transform.position += new Vector3(0, -10, 0);
            }
            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                shapeL.transform.position += new Vector3(0, 10, 0);
            }
            if (Input.GetKeyDown(KeyCode.RightArrow))
            {
                shapeL.transform.position += new Vector3(10, 0, 0);
            }
            if (Input.GetKeyDown(KeyCode.LeftArrow))
            {
                shapeL.transform.position += new Vector3(-10, 0, 0);
            }
            if (Input.GetKeyDown(KeyCode.Space))
            {

            }
            return;
        }
        else
        {

        }


    }
}
